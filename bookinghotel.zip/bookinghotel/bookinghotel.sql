-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: bookinghotel
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `booking`
--

DROP TABLE IF EXISTS `booking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `booking` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `amount_room` double DEFAULT NULL,
  `amount_service` double DEFAULT NULL,
  `cccd` varchar(255) DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_time` time(6) DEFAULT NULL,
  `from_date` date DEFAULT NULL,
  `fullname` varchar(255) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `num_date` int DEFAULT NULL,
  `pay_date` date DEFAULT NULL,
  `pay_status` tinyint DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `to_date` date DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  `discount` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK7udbel7q86k041591kj6lfmvw` (`user_id`),
  CONSTRAINT `FK7udbel7q86k041591kj6lfmvw` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking`
--

LOCK TABLES `booking` WRITE;
/*!40000 ALTER TABLE `booking` DISABLE KEYS */;
INSERT INTO `booking` VALUES (2,6790000,NULL,'342343','2025-03-21','07:06:47.305000','2025-03-21','Trần văn hiếu','no',1,'2025-03-21',1,'0987123123','2025-03-22',3,NULL),(3,6790000,NULL,'342343','2025-03-21','07:06:50.000000','2025-03-21','Trần văn hiếu','no',1,NULL,2,'0987123123','2025-03-22',3,NULL),(4,800000,NULL,'342343','2025-03-21','07:08:19.376000','2025-03-21','Trần văn hiếu','no',1,NULL,0,'0987123123','2025-03-22',3,NULL),(5,13580000,NULL,'342343','2025-03-21','17:06:47.408000','2025-03-24','Trần văn hiếu','gọi lại cho tôi',2,NULL,0,'0987123123','2025-03-26',4,NULL),(6,1106000,NULL,'23132345454366','2025-03-23','17:59:46.735000','2025-03-23','duy','',1,'2025-03-23',1,'0888664567','2025-03-24',1,NULL),(7,4600000,NULL,'23132345454','2025-04-01','08:59:39.748000','2025-04-02','Muoi','',2,NULL,0,'0888664567','2025-04-04',1,NULL),(8,7600000,NULL,'23132345454','2025-04-03','17:58:26.270000','2025-04-03','jame','',4,NULL,0,'0888664567','2025-04-07',NULL,NULL),(9,7600000,NULL,'23132345454','2025-04-03','17:58:38.308000','2025-04-03','jame','',4,'2025-04-03',1,'0888664567','2025-04-07',1,NULL),(10,6210000,NULL,'32434432432','2025-05-28','23:04:21.782000','2025-05-28','Duy Ngô Khánh','check-in sớm ',3,NULL,1,'08886574873','2025-05-31',7,0),(11,2300000,NULL,'32434432432','2025-05-28','23:08:26.042000','2025-05-28','Duy ','',1,NULL,1,'08886574873','2025-05-29',7,0),(12,1500000,NULL,'32434432432','2025-05-29','13:02:58.883000','2025-05-29','Duy Ngô Khánh','dsd',1,NULL,1,'08886574873','2025-05-30',7,0),(13,2100000,NULL,'23132345454366','2025-05-30','22:35:24.382000','2025-05-30','Duy Ngô ','',1,NULL,1,'0888664567','2025-05-31',7,200000),(14,1150000,NULL,'66555555','2025-06-06','08:49:38.121000','2025-06-06',' Duy','',1,NULL,1,'0981231232','2025-06-07',7,350000),(15,583000,NULL,'','2025-06-20','17:55:11.492000','2025-06-20','Diez','',1,NULL,1,'0379175462','2025-06-21',9,0);
/*!40000 ALTER TABLE `booking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `booking_room`
--

DROP TABLE IF EXISTS `booking_room`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `booking_room` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `from_date` date DEFAULT NULL,
  `num_day` int DEFAULT NULL,
  `price` double DEFAULT NULL,
  `to_date` date DEFAULT NULL,
  `booking_id` bigint DEFAULT NULL,
  `room_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK9umnt0pjb1nf83qwoqry1cuc2` (`booking_id`),
  KEY `FK4e002f18klgu08ekxnav2rwr9` (`room_id`),
  CONSTRAINT `FK4e002f18klgu08ekxnav2rwr9` FOREIGN KEY (`room_id`) REFERENCES `room` (`id`),
  CONSTRAINT `FK9umnt0pjb1nf83qwoqry1cuc2` FOREIGN KEY (`booking_id`) REFERENCES `booking` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking_room`
--

LOCK TABLES `booking_room` WRITE;
/*!40000 ALTER TABLE `booking_room` DISABLE KEYS */;
INSERT INTO `booking_room` VALUES (2,'2025-03-21',1,6790000,'2025-03-22',2,1),(3,'2025-03-21',1,6790000,'2025-03-22',3,1),(4,'2025-03-21',1,800000,'2025-03-22',4,2),(5,'2025-03-24',2,6790000,'2025-03-26',5,1),(6,'2025-03-23',1,1106000,'2025-03-24',6,3),(7,'2025-04-02',2,2300000,'2025-04-04',7,13),(8,'2025-04-03',4,1900000,'2025-04-07',9,16),(9,'2025-05-28',3,2070000,'2025-05-31',10,5),(10,'2025-05-28',1,2300000,'2025-05-29',11,13),(11,'2025-05-29',1,1500000,'2025-05-30',12,4),(12,'2025-05-30',1,2300000,'2025-05-31',13,13),(13,'2025-06-06',1,1500000,'2025-06-07',14,4),(14,'2025-06-20',1,583000,'2025-06-21',15,5);
/*!40000 ALTER TABLE `booking_room` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `category` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'Đà Lạt'),(2,'Hạ Long'),(3,'Phú Quốc'),(4,'Nha Trang'),(7,'Hà Nội'),(8,'Bình Dương'),(10,'Huế');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chatting`
--

DROP TABLE IF EXISTS `chatting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chatting` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `content` varchar(255) DEFAULT NULL,
  `created_date` datetime(6) DEFAULT NULL,
  `receiver` bigint DEFAULT NULL,
  `sender` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKfaewt5773gq00mr4rlgkvb3hi` (`receiver`),
  KEY `FKmiq947q3icuu8tlfjknw8uwih` (`sender`),
  CONSTRAINT `FKfaewt5773gq00mr4rlgkvb3hi` FOREIGN KEY (`receiver`) REFERENCES `users` (`id`),
  CONSTRAINT `FKmiq947q3icuu8tlfjknw8uwih` FOREIGN KEY (`sender`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chatting`
--

LOCK TABLES `chatting` WRITE;
/*!40000 ALTER TABLE `chatting` DISABLE KEYS */;
INSERT INTO `chatting` VALUES (1,'hi','2025-05-27 12:43:26.795000',NULL,1),(2,'hg','2025-05-27 12:43:35.309000',1,1),(3,'hello ','2025-05-27 12:48:36.169000',NULL,4),(4,'bạn cần hỗ trợ gì ??','2025-05-27 12:49:07.934000',4,1),(5,'hello','2025-05-27 17:06:20.698000',NULL,4),(6,'hiiiiiii','2025-05-27 17:06:44.198000',4,1),(7,'hello','2025-05-29 13:03:53.760000',NULL,7),(8,'hello','2025-05-29 13:04:51.444000',NULL,1),(9,'hhhhh','2025-05-29 13:04:55.957000',NULL,1),(10,'fff','2025-05-29 13:05:07.306000',7,1),(11,'hello admin','2025-06-06 08:50:07.581000',NULL,7),(12,'hii','2025-06-20 18:43:43.443000',NULL,9),(13,'hello','2025-06-20 18:44:17.192000',9,1);
/*!40000 ALTER TABLE `chatting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comment` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `content` varchar(255) DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_time` time(6) DEFAULT NULL,
  `star` float DEFAULT NULL,
  `hotel_id` bigint DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `full_name` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKej6lhabpn9qvujgc51lqlkmur` (`hotel_id`),
  KEY `FKqm52p1v3o13hy268he0wcngr5` (`user_id`),
  CONSTRAINT `FKej6lhabpn9qvujgc51lqlkmur` FOREIGN KEY (`hotel_id`) REFERENCES `hotel` (`id`),
  CONSTRAINT `FKqm52p1v3o13hy268he0wcngr5` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
INSERT INTO `comment` VALUES (4,'khách sạn sạch sẽ','2025-03-21','17:26:40.285000',4,4,'0981231242','Trần Văn Nam','nam@gmail.com',NULL),(5,'phục vụ kém','2025-03-21','17:27:07.347000',2,4,'0971231243','Hoàng văn tú','tu@gmail.com',NULL),(6,'Dịch vụ phòng tốt, buffer sáng rất ngon.','2025-03-23','17:52:51.438000',4,5,'0888664578','Duy','abvc@gmail.com',NULL),(7,'We had a Nice and pleasant stay. Very well mannered and helpful staffs. The salt coffee they served was one the best we had in all Hanoi.','2025-03-23','20:30:32.473000',5,12,'0192847586','Lerk','lerk@gmail.com',NULL),(8,'Great hotel with a beautiful view of the city. Friendly and helpful staff. I mistakenly booked a room with a view of the street, without any problems they immediately offered to change it to a room with a view of the city. The rooms are clean, the...','2025-03-23','20:31:46.339000',5,11,'0992867462','Leilamyratovna','leilamy2099@gmail.com',NULL),(9,'staff are helpful that help us to check in early when rooms available.\n- the location is right in the centre but the room is spacious\n- super clean, good smell','2025-03-23','20:33:00.294000',4,9,'0881375632','Trọng Ngô','Trongngo291@gmail.com',NULL),(10,' facilities is okay, great staff. The location is so far market','2025-03-23','20:34:58.258000',2,11,'0987124657','Long Le','longlekhanh1354@gmail.com',NULL),(11,'The hostess is cute and friendly. The room is spacious, the interior is dirty and bad smell room','2025-03-23','20:36:52.469000',2,1,'0887794146','Khoa Nguyen','khoasecuri@gmail.com',NULL),(12,'Good location near the train station, yet tucked away in a noisy street','2025-03-23','20:38:20.414000',3,13,'0988573813','Jay Smith','Jaysonsmith091@gmail.com',NULL),(13,'The location was perfect, and close to the beach and esplanade, restaurants and markets. Breakfast was great. Oceanview room was amazing. Amazing views. Bathroom also has oceanviews. Room very spacious and comfortable and quiet','2025-03-23','20:42:27.180000',4,13,'0882745813','Phong Nguyen','phongsuper821@gmail.com',NULL),(14,'Hotel is comfort, you have everything you need. Rooms are big and they have bife breakfast. People are kind and we had a wonderful stay there. I recomend this hotel everyone who want to see Hue and','2025-03-23','20:50:23.953000',4,14,'0987164424','Vladosa','vladosason@gmail.com',NULL);
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `history_pay`
--

DROP TABLE IF EXISTS `history_pay`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `history_pay` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_date` date DEFAULT NULL,
  `created_time` time(6) DEFAULT NULL,
  `order_id` varchar(255) DEFAULT NULL,
  `request_id` varchar(255) DEFAULT NULL,
  `total_amount` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `history_pay`
--

LOCK TABLES `history_pay` WRITE;
/*!40000 ALTER TABLE `history_pay` DISABLE KEYS */;
INSERT INTO `history_pay` VALUES (1,'2025-05-28','23:04:21.821000','1748448156989','1748448156989',6210000),(2,'2025-05-28','23:08:26.061000','1748448473970','1748448473970',2300000),(3,'2025-05-29','13:02:58.958000','1748498530014','1748498530014',1500000),(4,'2025-05-30','22:35:24.451000','1748619285774','1748619285774',2100000),(5,'2025-06-06','08:49:38.224000','1749174535202','1749174535202',1150000),(6,'2025-06-20','17:55:11.696000','1750416822624','1750416822624',583000);
/*!40000 ALTER TABLE `history_pay` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hotel`
--

DROP TABLE IF EXISTS `hotel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hotel` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `address` varchar(255) DEFAULT NULL,
  `avg_price` double DEFAULT NULL,
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `image` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `num_rating` int DEFAULT NULL,
  `star` float DEFAULT NULL,
  `category_id` bigint DEFAULT NULL,
  `link_map` longtext,
  PRIMARY KEY (`id`),
  KEY `FKcwvmmtpfa1hsm8gwya0k0hmfk` (`category_id`),
  CONSTRAINT `FKcwvmmtpfa1hsm8gwya0k0hmfk` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hotel`
--

LOCK TABLES `hotel` WRITE;
/*!40000 ALTER TABLE `hotel` DISABLE KEYS */;
INSERT INTO `hotel` VALUES (1,'12 Hạ Long, Bãi Cháy, Hạ Long, Quảng Ninh',1124000,'<p>Wyndham Legend Halong Hotel l&agrave; kh&aacute;ch sạn sang trọng 5 sao nằm dọc theo b&atilde;i biển B&atilde;i Ch&aacute;y, c&oacute; tầm nh&igrave;n tuyệt đẹp ra Vịnh Hạ Long. Kh&aacute;ch sạn c&oacute; 217 ph&ograve;ng v&agrave; suite rộng r&atilde;i với tầm nh&igrave;n ra biển, tiện nghi hiện đại v&agrave; Wi-Fi tốc độ cao. Du kh&aacute;ch c&oacute; thể thưởng thức nhiều lựa chọn ăn uống đa dạng bao gồm tiệc tự chọn quốc tế, ẩm thực Nhật Bản v&agrave; ẩm thực &Yacute; hảo hạng. C&aacute;c tiện nghi bao gồm hồ bơi ngo&agrave;i trời, khu vui chơi cho trẻ em, trung t&acirc;m thể dục v&agrave; spa cung cấp đầy đủ dịch vụ. Với vị tr&iacute; đắc địa gần c&aacute;c điểm tham quan du lịch v&agrave; kh&ocirc;ng gian tổ chức sự kiện chuy&ecirc;n nghiệp, kh&aacute;ch sạn l&yacute; tưởng cho cả du kh&aacute;ch giải tr&iacute; v&agrave; c&ocirc;ng t&aacute;c.</p>','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742210107/awxv0qfq5heabpi8vrq7.jpg','Wyndham Legend Halong Hotel',0,2,2,'<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d18606.83261895845!2d107.05433121739595!3d20.95729077690599!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x314a58672e65a445%3A0x915b6e28bd64ed97!2sWyndham%20Legend%20Halong%20Hotel!5e1!3m2!1sen!2s!4v1750199615894!5m2!1sen!2s\" width=\"600\" height=\"450\" style=\"border:0;\" allowfullscreen=\"\" loading=\"lazy\" referrerpolicy=\"no-referrer-when-downgrade\"></iframe>'),(3,'49A Đường Hà Huy Tập, Phường 3, Đà Lạt, Lâm Đồng',666000,'<p>Kh&aacute;ch sạn Royal Palace Đ&agrave; Lạt l&agrave; kh&aacute;ch sạn 3 sao ấm c&uacute;ng nằm ở trung t&acirc;m Đ&agrave; Lạt, chỉ c&aacute;ch Chợ Đ&ecirc;m v&agrave; Hồ Xu&acirc;n Hương một đoạn đi bộ ngắn. Kh&aacute;ch sạn c&oacute; c&aacute;c ph&ograve;ng được trang bị đầy đủ tiện nghi hiện đại bao gồm Wi-Fi miễn ph&iacute;, minibar, TV m&agrave;n h&igrave;nh phẳng v&agrave; ph&ograve;ng tắm ri&ecirc;ng. Du kh&aacute;ch c&oacute; thể thưởng thức ẩm thực tại chỗ, qu&aacute;n c&agrave; ph&ecirc; y&ecirc;n tĩnh, dịch vụ x&ocirc;ng hơi kh&ocirc; v&agrave; dịch vụ cho thu&ecirc; xe m&aacute;y. Với vị tr&iacute; trung t&acirc;m, đội ngũ nh&acirc;n vi&ecirc;n th&acirc;n thiện v&agrave; gi&aacute; cả phải chăng, kh&aacute;ch sạn mang đến cho du kh&aacute;ch kỳ nghỉ tiện lợi v&agrave; thoải m&aacute;i khi kh&aacute;m ph&aacute; th&agrave;nh phố.</p>','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742210140/zbs2mjbzsjvkfqkdmpur.jpg','Royal Palace Da Lat Hotel',0,0,1,'<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d6892.17106260206!2d108.43802363694012!3d11.937726239684169!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x317113208ce4d463%3A0xd7d21d0aaca77abb!2zS2jDoWNoIFPhuqFuIFJveWFsIFBhbGFjZSDEkMOgIEzhuqF0!5e1!3m2!1sen!2s!4v1750200533202!5m2!1sen!2s\" width=\"600\" height=\"450\" style=\"border:0;\" allowfullscreen=\"\" loading=\"lazy\" referrerpolicy=\"no-referrer-when-downgrade\"></iframe>'),(4,'Bãi Dài, Gành Dầu, Phú Quốc, Kiên Giang',2051000,'<p>Vinpearl Resort &amp; Spa Ph&uacute; Quốc l&agrave; khu nghỉ dưỡng 5 sao sang trọng nằm ngay b&atilde;i biển B&atilde;i D&agrave;i, c&oacute; tầm nh&igrave;n tuyệt đẹp ra biển v&agrave; kiến ​​tr&uacute;c theo phong c&aacute;ch Đ&ocirc;ng Dương thanh lịch. Khu nghỉ dưỡng c&oacute; c&aacute;c ph&ograve;ng, suite v&agrave; biệt thự rộng r&atilde;i với c&aacute;c tiện nghi hiện đại, nhiều ph&ograve;ng c&oacute; hồ bơi ri&ecirc;ng v&agrave; tầm nh&igrave;n ra khu vườn. Du kh&aacute;ch c&oacute; thể thư gi&atilde;n tại hồ bơi ngo&agrave;i trời lớn nhất Việt Nam, tận hưởng c&aacute;c liệu ph&aacute;p đẳng cấp thế giới tại VinCharm Spa v&agrave; d&ugrave;ng bữa tại nhiều nh&agrave; h&agrave;ng trong khu&ocirc;n vi&ecirc;n phục vụ ẩm thực quốc tế v&agrave; Việt Nam. Với b&atilde;i biển ri&ecirc;ng, c&acirc;u lạc bộ trẻ em, trung t&acirc;m thể dục v&agrave; dễ d&agrave;ng đi đến VinWonders, Safari v&agrave; Grand World, đ&acirc;y l&agrave; điểm đến l&yacute; tưởng cho c&aacute;c gia đ&igrave;nh, cặp đ&ocirc;i v&agrave; du kh&aacute;ch cao cấp.</p>','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742210237/ccx05hj3mcnhby9o77uq.jpg','Vinpearl Resort & Spa Phú Quốc',0,3,3,'<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d39200.614716814394!2d103.85653262684718!3d10.35650797895862!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31081e3b9fdc2f85%3A0x1a649fb7cb98ca00!2zVmlucGVhcmwgUmVzb3J0ICYgU3BhIFBow7ogUXXhu5Fj!5e1!3m2!1sen!2s!4v1750200918858!5m2!1sen!2s\" width=\"600\" height=\"450\" style=\"border:0;\" allowfullscreen=\"\" loading=\"lazy\" referrerpolicy=\"no-referrer-when-downgrade\"></iframe>'),(5,'Đ. Hoa Hồng, Phường 4, Đà Lạt, Lâm Đồng ',2549000,'<p>Mơ Stay &ndash; Forest Resort l&agrave; nơi nghỉ dưỡng y&ecirc;n tĩnh nằm giữa những c&aacute;nh rừng th&ocirc;ng gần Hồ Tuyền L&acirc;m ở Đ&agrave; Lạt. Kết hợp n&eacute;t quyến rũ mộc mạc với sự thoải m&aacute;i hiện đại, khu nghỉ dưỡng cung cấp c&aacute;c ph&ograve;ng nghỉ v&agrave; biệt thự ấm c&uacute;ng với tầm nh&igrave;n ra khu vườn hoặc khu rừng, bầu kh&ocirc;ng kh&iacute; y&ecirc;n b&igrave;nh v&agrave; l&ograve;ng hiếu kh&aacute;ch nồng hậu. Du kh&aacute;ch c&oacute; thể thưởng thức bữa s&aacute;ng kiểu &Aacute;-&Acirc;u miễn ph&iacute;, qu&aacute;n c&agrave; ph&ecirc; v&agrave; nh&agrave; h&agrave;ng tại chỗ, c&aacute;c buổi tập yoga v&agrave; c&aacute;c tiện nghi th&acirc;n thiện với trẻ em. Với khung cảnh thi&ecirc;n nhi&ecirc;n thanh b&igrave;nh v&agrave; gần c&aacute;c điểm tham quan như Thiền viện Tr&uacute;c L&acirc;m, đ&acirc;y l&agrave; nơi nghỉ dưỡng l&yacute; tưởng cho c&aacute;c gia đ&igrave;nh, cặp đ&ocirc;i v&agrave; những người y&ecirc;u thi&ecirc;n nhi&ecirc;n t&igrave;m kiếm sự thư gi&atilde;n.</p>','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742726527/qjlqbhrafmllivj97f88.png','Mơ Stay - Forest Resort',0,4,1,'<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d27572.820593432825!2d108.39840989696731!3d11.89699701725346!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31716b01276262ab%3A0x96d306fd7f1f53fd!2sM%C6%A1%20Stay%20-%20Forest%20Resort!5e1!3m2!1sen!2s!4v1750201338089!5m2!1sen!2s\" width=\"600\" height=\"450\" style=\"border:0;\" allowfullscreen=\"\" loading=\"lazy\" referrerpolicy=\"no-referrer-when-downgrade\"></iframe>'),(9,'46 Trần Phú, Lộc Thọ, Nha Trang, Khánh Hòa',583000,'<p><span class=\"relative -mx-px my-[-0.2rem] rounded px-px py-[0.2rem] transition-colors duration-100 ease-in-out\"><span>Kh&aacute;ch sạn &amp; Căn hộ Panorama Nha Trang l&agrave; kh&aacute;ch sạn căn hộ hiện đại 3,5&ndash;4 sao ngay tr&ecirc;n b&atilde;i biển Trần Ph&uacute;, ngay trung t&acirc;m th&agrave;nh phố Nha Trang.</span></span><span>&nbsp;</span><span class=\"relative -mx-px my-[-0.2rem] rounded px-px py-[0.2rem] transition-colors duration-100 ease-in-out\"><span>Nằm trong t&ograve;a th&aacute;p 39 tầng nổi bật, nơi đ&acirc;y c&oacute; khoảng 1.200 ph&ograve;ng studio v&agrave; căn hộ được trang bị đầy đủ tiện nghi&mdash;nhiều ph&ograve;ng c&oacute; ban c&ocirc;ng v&agrave; bếp nhỏ&mdash;c&oacute; tầm nh&igrave;n bao qu&aacute;t ra biển, th&agrave;nh phố hoặc n&uacute;i</span></span> <span> . </span><span class=\"relative -mx-px my-[-0.2rem] rounded px-px py-[0.2rem] transition-colors duration-100 ease-in-out\"><span>Du kh&aacute;ch được tận hưởng ph&ograve;ng tập thể dục 24 giờ, qu&aacute;n c&agrave; ph&ecirc;, dịch vụ đỗ xe c&oacute; người phục vụ v&agrave; quyền sử dụng cả hồ bơi trong khu&ocirc;n vi&ecirc;n v&agrave; hồ bơi ngo&agrave;i trời của đối t&aacute;c, bao gồm hồ bơi v&ocirc; cực tr&ecirc;n tầng thượng ở tầng cao nhất</span></span><span>. </span><span class=\"relative -mx-px my-[-0.2rem] rounded px-px py-[0.2rem] transition-colors duration-100 ease-in-out\"><span>Với vị tr&iacute; đắc địa ngay bờ biển, chỉ c&aacute;ch Chợ đ&ecirc;m, Th&aacute;p Trầm Hương v&agrave; c&aacute;c qu&aacute;n ăn địa phương v&agrave;i bước ch&acirc;n, đ&acirc;y l&agrave; lựa chọn tiện lợi, thời trang cho cả gia đ&igrave;nh v&agrave; du kh&aacute;ch độc lập t&igrave;m kiếm sự linh hoạt v&agrave; thoải m&aacute;i.</span></span></p>','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742734464/rsxgjz8v3z3tmc22ydti.png','Panorama Nha Trang Hotel',0,4,4,'<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3442.2085335523266!2d109.19281377446026!3d12.238875088013215!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x317067a139b1bd1f%3A0xe700be367327b077!2sPanorama%20Nha%20Trang%20Hotel!5e1!3m2!1sen!2s!4v1750201834945!5m2!1sen!2s\" width=\"600\" height=\"450\" style=\"border:0;\" allowfullscreen=\"\" loading=\"lazy\" referrerpolicy=\"no-referrer-when-downgrade\"></iframe>'),(11,'6 Đường Đống Đa, Phường 3, Đà Lạt, Lâm Đồng',1080000,'<p>New Life Hotel &ndash; Đ&agrave; Lạt l&agrave; kh&aacute;ch sạn 3 sao ấm c&uacute;ng nằm tr&ecirc;n một ngọn đồi y&ecirc;n tĩnh gần trung t&acirc;m th&agrave;nh phố, cung cấp tầm nh&igrave;n to&agrave;n cảnh Đ&agrave; Lạt từ c&aacute;c ph&ograve;ng nghỉ rộng r&atilde;i, hiện đại. Mỗi ph&ograve;ng đều c&oacute; ban c&ocirc;ng ri&ecirc;ng, TV m&agrave;n h&igrave;nh phẳng, minibar v&agrave; Wi-Fi miễn ph&iacute;. Du kh&aacute;ch c&oacute; thể tận hưởng nh&agrave; h&agrave;ng tại chỗ, s&acirc;n thượng, dịch vụ spa v&agrave; dịch vụ cho thu&ecirc; xe m&aacute;y. Với đội ngũ nh&acirc;n vi&ecirc;n th&acirc;n thiện, tiện nghi thuận tiện v&agrave; bầu kh&ocirc;ng kh&iacute; y&ecirc;n b&igrave;nh, đ&acirc;y l&agrave; lựa chọn l&yacute; tưởng cho c&aacute;c cặp đ&ocirc;i v&agrave; gia đ&igrave;nh đến thăm v&ugrave;ng cao nguy&ecirc;n l&atilde;ng mạn của Đ&agrave; Lạt.</p>','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742735697/goqfgjvkeiabpvb88xdt.png','New Life Hotel - Da Lat',0,3,1,'<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3446.2409995894036!2d108.44239137445466!3d11.925493888301961!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3171137249c4733b%3A0xeb6176934624a7a4!2zTmV3IExpZmUgSG90ZWwgxJDDoCBM4bqhdA!5e1!3m2!1sen!2s!4v1750202169649!5m2!1sen!2s\" width=\"600\" height=\"450\" style=\"border:0;\" allowfullscreen=\"\" loading=\"lazy\" referrerpolicy=\"no-referrer-when-downgrade\"></iframe>'),(12,'18 P. Đào Duy Từ, Hàng Buồm, Hoàn Kiếm, Hà Nội ',817000,'<p>La Palm Boutique Hotel Hanoi l&agrave; kh&aacute;ch sạn 3,5 sao đầy phong c&aacute;ch nằm ở trung t&acirc;m Phố cổ H&agrave; Nội, chỉ c&aacute;ch Hồ Ho&agrave;n Kiếm v&agrave; Chợ đ&ecirc;m một đoạn đi bộ ngắn. Kh&aacute;ch sạn cung cấp c&aacute;c ph&ograve;ng nghỉ trang nh&atilde;, được trang bị đầy đủ tiện nghi hiện đại như m&aacute;y lạnh, Wi-Fi miễn ph&iacute;, TV m&agrave;n h&igrave;nh phẳng v&agrave; minibar. Một số ph&ograve;ng c&oacute; ban c&ocirc;ng nh&igrave;n ra quang cảnh th&agrave;nh phố nhộn nhịp. Du kh&aacute;ch được tận hưởng dịch vụ c&aacute; nh&acirc;n h&oacute;a, bữa s&aacute;ng tự chọn h&agrave;ng ng&agrave;y, spa tại chỗ v&agrave; dễ d&agrave;ng đi đến c&aacute;c điểm tham quan nổi tiếng, khiến nơi đ&acirc;y trở th&agrave;nh điểm dừng ch&acirc;n ho&agrave;n hảo để kh&aacute;m ph&aacute; n&eacute;t quyến rũ v&agrave; văn h&oacute;a của H&agrave; Nội.</p>','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742735881/yay87ljq5h5wvyvo8n1e.png','La Palm Boutique Hotel Hanoi',0,5,7,'<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3287.5155272161637!2d105.85072784115623!3d21.036231076446004!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3135ab49579bc4a3%3A0xf95246703939a142!2sLa%20Palm%20Boutique%20Hotel%20Hanoi!5e1!3m2!1sen!2s!4v1750202476474!5m2!1sen!2s\" width=\"600\" height=\"450\" style=\"border:0;\" allowfullscreen=\"\" loading=\"lazy\" referrerpolicy=\"no-referrer-when-downgrade\"></iframe>'),(13,'555B Đại lộ Bình Dương, Hiệp Thành, Thủ Dầu Một, Bình Dương',1390000,'<p>Kh&aacute;ch sạn Mira B&igrave;nh Dương l&agrave; kh&aacute;ch sạn 5 sao đầu ti&ecirc;n tại Th&agrave;nh phố Thủ Dầu Một, cung cấp chỗ nghỉ sang trọng v&agrave; tiện nghi hiện đại ngay trung t&acirc;m B&igrave;nh Dương. Với 186 ph&ograve;ng v&agrave; suite thanh lịch c&oacute; tầm nh&igrave;n ra th&agrave;nh phố hoặc hồ bơi, kh&aacute;ch sạn cung cấp c&aacute;c tiện nghi cao cấp bao gồm hồ bơi ngo&agrave;i trời, spa, trung t&acirc;m thể dục, s&ograve;ng bạc v&agrave; nhiều lựa chọn ăn uống. Vị tr&iacute; trung t&acirc;m tr&ecirc;n Đại lộ B&igrave;nh Dương, c&ugrave;ng với dịch vụ chuy&ecirc;n nghiệp v&agrave; kh&ocirc;ng gian sự kiện cho hội nghị hoặc đ&aacute;m cưới, khiến nơi đ&acirc;y trở th&agrave;nh lựa chọn h&agrave;ng đầu cho cả kh&aacute;ch du lịch c&ocirc;ng t&aacute;c v&agrave; giải tr&iacute;.</p>','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742737259/ylaabewfvfon48bwiu2o.png','The Mira Hotel',0,3,8,'<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2055.959599368511!2d106.66332543078684!3d10.987162908174989!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3174d122aec5beed%3A0xebd22203e01d31b2!2sThe%20Mira%20Hotel!5e1!3m2!1sen!2s!4v1750202898100!5m2!1sen!2s\" width=\"600\" height=\"450\" style=\"border:0;\" allowfullscreen=\"\" loading=\"lazy\" referrerpolicy=\"no-referrer-when-downgrade\"></iframe>'),(14,'17 Nguyễn Huệ, Vĩnh Ninh, Huế, Thành phố Huế',988000,'<p>Mondial Hotel l&agrave; kh&aacute;ch sạn 4 sao hiện đại nằm ở trung t&acirc;m th&agrave;nh phố Huế, chỉ c&aacute;ch S&ocirc;ng Hương v&agrave; Ho&agrave;ng th&agrave;nh một qu&atilde;ng đi bộ ngắn. Kh&aacute;ch sạn c&oacute; c&aacute;c ph&ograve;ng v&agrave; suite rộng r&atilde;i với ban c&ocirc;ng nh&igrave;n ra quang cảnh th&agrave;nh phố, khu vườn hoặc d&ograve;ng s&ocirc;ng, c&ugrave;ng với c&aacute;c tiện nghi như minibar, k&eacute;t an to&agrave;n v&agrave; bồn tắm ng&acirc;m. Kh&aacute;ch sạn c&oacute; hồ bơi ngo&agrave;i trời, spa, ph&ograve;ng x&ocirc;ng hơi kh&ocirc; v&agrave; nhiều lựa chọn ăn uống, bao gồm nh&agrave; h&agrave;ng tr&ecirc;n tầng thượng với tầm nh&igrave;n to&agrave;n cảnh. Với vị tr&iacute; thuận tiện v&agrave; tiện nghi thoải m&aacute;i, đ&acirc;y l&agrave; lựa chọn tuyệt vời cho cả kh&aacute;ch du lịch v&agrave; kh&aacute;ch c&ocirc;ng t&aacute;c kh&aacute;m ph&aacute; Huế.</p>\n<p>&nbsp;</p>\n<p>&nbsp;</p>\n<p>&nbsp;</p>\n<p>&nbsp;</p>\n<p>&nbsp;</p>','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742737562/nujkhvsfolzztn02zqro.png','Mondial Hotel ',0,4,10,'<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3377.9494113155997!2d107.58067727455156!3d16.457817384279398!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3141a149b54e0a23%3A0x7302c23a15f28261!2sMondial%20Hotel%20Hue!5e1!3m2!1sen!2s!4v1750203394382!5m2!1sen!2s\" width=\"600\" height=\"450\" style=\"border:0;\" allowfullscreen=\"\" loading=\"lazy\" referrerpolicy=\"no-referrer-when-downgrade\"></iframe>');
/*!40000 ALTER TABLE `hotel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hotel_image`
--

DROP TABLE IF EXISTS `hotel_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hotel_image` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `image` varchar(255) DEFAULT NULL,
  `hotel_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK293ve9b0ocbfji4u5hl2oh3ks` (`hotel_id`),
  CONSTRAINT `FK293ve9b0ocbfji4u5hl2oh3ks` FOREIGN KEY (`hotel_id`) REFERENCES `hotel` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hotel_image`
--

LOCK TABLES `hotel_image` WRITE;
/*!40000 ALTER TABLE `hotel_image` DISABLE KEYS */;
INSERT INTO `hotel_image` VALUES (28,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1750200057/gaeunpcp6jdqq8ogeinv.png',1),(29,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1750200058/p7mgi0m4ymk84kaipsip.png',1),(30,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1750200058/fhor4xq2jhl8gxqvyimn.png',1),(31,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1750200059/fixwhw2w3pjuxqr8gmxx.png',1),(32,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1750200733/hdjdvtynnuabuuhlavrk.png',3),(33,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1750200738/szez7fnprqn6b2puenow.png',3),(34,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1750200740/p92l1m00kcjnmgfbxtsn.png',3),(35,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1750201217/qapz5uwx0vsuhtgg1dim.png',4),(36,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1750201218/a5zaawbosazix3eguzuj.png',4),(37,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1750201221/dtpluzjwm9uoea1rp2zi.png',4),(38,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1750201610/niuwuzlqfq5eeye3tpta.png',5),(39,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1750201610/es25yuxwvy64dvqkbgpk.png',5),(40,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1750201611/fogtexx4ub0tg760n6b8.png',5),(41,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1750202039/azyga2ehkvakm898r14b.png',9),(42,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1750202039/nboxxs3bwli5refckxez.png',9),(43,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1750202043/zdmxqvsj8rymhdqsfl7n.png',9),(44,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1750202369/cnsrywerikcek1y85s61.png',11),(45,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1750202369/hse7cbwplosyw7bbngqw.png',11),(46,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1750202370/eb2pmvl8ncrmuo0kiwup.png',11),(47,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1750202666/bslz65esy1fhxvggxsod.png',12),(48,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1750202667/hib1leouioewemm7zdsm.png',12),(49,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1750202667/uqgypjuivybeze1mvcfi.png',12),(50,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1750203089/bg17awqmmsh99iqtbsci.png',13),(51,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1750203089/xkzgkol1azdddcxg22xw.png',13),(52,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1750203090/udejpdl7iqecmk6knbgh.png',13),(53,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1750203448/mwlj6b5cj5wf9o4q7joo.png',14),(54,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1750203448/dleqdgwxuqlvso2hzov4.png',14),(55,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1750203450/hsyfb7zdvmedfnaccmdj.png',14);
/*!40000 ALTER TABLE `hotel_image` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hotel_utilities`
--

DROP TABLE IF EXISTS `hotel_utilities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hotel_utilities` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `hotel_id` bigint DEFAULT NULL,
  `utilities_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKjv8qsx728xr6inv6i5dd11l6c` (`hotel_id`),
  KEY `FKgqwe30jgrtteeb5gf287mirx6` (`utilities_id`),
  CONSTRAINT `FKgqwe30jgrtteeb5gf287mirx6` FOREIGN KEY (`utilities_id`) REFERENCES `utilities` (`id`),
  CONSTRAINT `FKjv8qsx728xr6inv6i5dd11l6c` FOREIGN KEY (`hotel_id`) REFERENCES `hotel` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=227 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hotel_utilities`
--

LOCK TABLES `hotel_utilities` WRITE;
/*!40000 ALTER TABLE `hotel_utilities` DISABLE KEYS */;
INSERT INTO `hotel_utilities` VALUES (145,1,1),(146,1,2),(147,1,3),(148,1,4),(149,1,5),(150,1,7),(151,1,9),(152,3,1),(153,3,2),(154,3,4),(155,3,7),(156,3,8),(157,3,10),(158,4,1),(159,4,3),(160,4,4),(161,4,5),(162,4,9),(170,9,1),(171,9,2),(172,9,3),(173,9,5),(174,9,8),(175,9,10),(194,12,1),(195,12,2),(196,12,3),(197,12,4),(198,12,5),(199,12,7),(200,13,1),(201,13,2),(202,13,3),(203,13,4),(209,5,1),(210,5,2),(211,5,3),(212,5,4),(213,5,5),(214,5,6),(215,5,7),(216,14,1),(217,14,2),(218,14,3),(219,14,4),(220,14,6),(221,11,1),(222,11,2),(223,11,3),(224,11,4),(225,11,9),(226,11,10);
/*!40000 ALTER TABLE `hotel_utilities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `room`
--

DROP TABLE IF EXISTS `room`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `room` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `max_people` int DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `num_bed` int DEFAULT NULL,
  `price` double DEFAULT NULL,
  `hotel_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKdosq3ww4h9m2osim6o0lugng8` (`hotel_id`),
  CONSTRAINT `FKdosq3ww4h9m2osim6o0lugng8` FOREIGN KEY (`hotel_id`) REFERENCES `hotel` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room`
--

LOCK TABLES `room` WRITE;
/*!40000 ALTER TABLE `room` DISABLE KEYS */;
INSERT INTO `room` VALUES (1,'','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742119860/gmd9plv9btnbw0qquhlv.jpg',2,'Junior Suite with Terrace',1,2051000,4),(2,'<p>đ&acirc;y l&agrave; m&ocirc; tả</p>','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742295762/qqhgcrenoumdggcahd6r.jpg',6,'Duplex Suite',3,2666000,4),(3,'','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742734896/zw1ckwsaoberyudlwhj7.png',2,'Phòng Deluxe Giường Đôi',1,2549000,5),(4,'','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742734591/tgylzztzsl1xknd2txff.png',4,'Studio with Mountain View',2,758000,9),(5,'','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742734690/dlou0eu7dp5xkvazxox3.png',2,'Apartment with Sea View',1,583000,9),(6,'','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742734802/becc4fzc5jnngrm5al5z.png',4,'Phòng Deluxe Giường Đôi',2,3186000,5),(7,'','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742735110/xfq6sbkcjvck6qknmenu.png',2,'Deluxe Room with Balcony',1,1124000,1),(8,'','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742735240/augfsmsh9wwrlahdk7ld.png',4,'Family Room with Balcony',2,1573000,1),(9,'','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742735357/nyhmczdxnrfbyxk1zomy.png',2,'Superior King Room',1,666000,3),(10,'','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742735443/qar5kfmusislrfeoueti.png',4,'Deluxe Double Room',2,865000,3),(11,'','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742735987/i06johi059eauyabalzc.png',3,'Deluxe Triple Room',2,1062000,12),(12,'','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742736076/ffrcopzq8dhn2ywynnl8.png',2,'Superior Double',2,817000,12),(13,'','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742736239/ewdyqsfs2o0qz0hqdopx.png',6,'Deluxe Family Room',3,1080000,11),(14,'','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742736435/h2lrtzaiudfl5hmnhyhm.png',2,'Standard Apartment',1,1390000,13),(15,'','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742736552/uimu9z6ubxaqy2ytagge.png',4,'Two-Bedroom Apartment',2,1807000,13),(16,'','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742737628/xoor6emvumjwgjq5qlhk.png',2,'Twin Room with City View',2,1037000,14),(17,'','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742737739/moc7cg80zbhwgdgxhosh.png',2,'Suite River View',1,988000,14);
/*!40000 ALTER TABLE `room` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `room_image`
--

DROP TABLE IF EXISTS `room_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `room_image` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `image` varchar(255) DEFAULT NULL,
  `room_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKcme41omxvwoj00bhqk7fwt70v` (`room_id`),
  CONSTRAINT `FKcme41omxvwoj00bhqk7fwt70v` FOREIGN KEY (`room_id`) REFERENCES `room` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room_image`
--

LOCK TABLES `room_image` WRITE;
/*!40000 ALTER TABLE `room_image` DISABLE KEYS */;
INSERT INTO `room_image` VALUES (1,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1742119861/wttuptoua9fkpfx9puod.jpg',1),(2,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1742119861/adsyqzm5nurknx6zlgly.jpg',1),(3,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1742119861/fj4xomf0kterwogv5xtb.jpg',1),(4,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1742119861/vt4r1ceo2l9jeamrviqv.jpg',1),(5,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1742295764/n37znnkc1g9dmsgclytd.jpg',2),(6,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1742295764/g6jglplx5jhoubrxfdcb.jpg',2),(7,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1742295764/hfvjglbw2wrifx9rzr33.jpg',2),(8,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1742727355/vdt28qfevkb09ebtey2o.png',3);
/*!40000 ALTER TABLE `room_image` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `room_utilities`
--

DROP TABLE IF EXISTS `room_utilities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `room_utilities` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `room_id` bigint DEFAULT NULL,
  `utility_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKgymhu6h1hawo02mk1lywlvt1m` (`room_id`),
  KEY `FKq0n1xboq4yonnp9rslciw6ye2` (`utility_id`),
  CONSTRAINT `FKgymhu6h1hawo02mk1lywlvt1m` FOREIGN KEY (`room_id`) REFERENCES `room` (`id`),
  CONSTRAINT `FKq0n1xboq4yonnp9rslciw6ye2` FOREIGN KEY (`utility_id`) REFERENCES `utilities` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=268 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room_utilities`
--

LOCK TABLES `room_utilities` WRITE;
/*!40000 ALTER TABLE `room_utilities` DISABLE KEYS */;
INSERT INTO `room_utilities` VALUES (129,1,1),(130,1,2),(131,1,3),(132,1,4),(133,2,1),(134,2,3),(135,2,4),(136,2,5),(137,3,2),(138,3,5),(139,3,10),(161,5,1),(162,5,2),(163,5,3),(164,5,7),(165,4,1),(166,4,2),(167,4,6),(168,4,9),(169,6,1),(170,6,3),(171,6,5),(172,6,6),(173,6,7),(174,7,1),(175,7,2),(176,7,3),(177,7,4),(178,7,10),(179,8,1),(180,8,2),(181,8,3),(182,8,4),(183,8,5),(184,8,6),(185,8,7),(186,8,8),(187,9,1),(188,9,2),(189,9,3),(190,9,4),(191,9,7),(192,9,9),(193,10,1),(194,10,3),(195,10,4),(196,10,5),(197,10,9),(198,10,10),(207,11,1),(208,11,2),(209,11,4),(210,11,5),(211,12,2),(212,12,6),(213,12,7),(214,12,9),(225,13,1),(226,13,2),(227,13,3),(228,13,4),(229,13,5),(230,13,6),(231,13,7),(232,13,8),(233,13,9),(234,13,10),(235,14,1),(236,14,3),(237,14,8),(238,14,9),(239,15,1),(240,15,2),(241,15,3),(242,15,5),(243,15,7),(244,17,1),(245,17,3),(246,17,4),(247,17,5),(248,17,6),(249,17,7),(250,17,9),(251,17,10),(260,16,1),(261,16,2),(262,16,3),(263,16,5),(264,16,6),(265,16,7),(266,16,9),(267,16,10);
/*!40000 ALTER TABLE `room_utilities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `activation_key` varchar(255) DEFAULT NULL,
  `actived` bit(1) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `full_name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `role` enum('ROLE_ADMIN','ROLE_USER') DEFAULT NULL,
  `user_type` tinyint DEFAULT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `users_chk_1` CHECK ((`user_type` between 0 and 1))
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,NULL,_binary '',NULL,NULL,'admin@gmail.com','ADMIN','$2a$10$lgWN38DZcBkTP0LLTo7A3.X1RHQ631WQHkHPhFeBI4PADwhMpBYi6',NULL,'ROLE_ADMIN',NULL),(3,NULL,_binary '',NULL,'2025-03-19','hieutran02102804@gmail.com',NULL,'$2a$10$uIvo0Hr8xhZKHwN9NoNYf.YHAVfmskPOadyONFtZdj8wlSb4XmjTS','0932478234','ROLE_USER',NULL),(4,NULL,_binary '','51 Nam Kỳ Khởi Nghĩa , Thủ Dầu Một , Bình Dương','2025-03-21','duyngo288@gmail.com','Duy','$2a$10$npOL77KCu0zsih.nXbr26uUZc2NfGHuL5UFnzpCtfe5jDG09Rvxsy','0981231232','ROLE_USER',NULL),(5,'852584',_binary '',NULL,'2025-05-27','thien.nguyentuan.cit21@edu.vn',NULL,'$2a$10$0ejhau4K8fA9uXlVVevyTuxfMMqoNJZF8Tvut6wDHfc6xu1/3Fd4G','0876854336','ROLE_USER',NULL),(6,'191714',_binary '\0','','2025-05-27','thien.nguyentuan.cit21@eiu.edu.vn','Thiện ','$2a$10$458CaKxhKvGOFDjdZtQ4Q.ERUr20kDfigfkLtcUxJRfL5giztQDtu','0876854336','ROLE_USER',NULL),(7,NULL,_binary '\0','','2025-05-28','duy.ngo.set18@eiu.edu.vn','Khánh Duy',NULL,'0981231232','ROLE_USER',0),(8,NULL,_binary '',NULL,'2025-06-18','muoind1@gmail.com','Duy Mười',NULL,NULL,'ROLE_USER',0),(9,'199637',_binary '','','2025-06-18','soydiez02@gmail.com','Diez','$2a$10$Ak2BQOKluIbRwgt6Q.yzZerks.7QLZyJ4dtuxL74X4UGiS2EJLAsS','0379175462','ROLE_USER',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `utilities`
--

DROP TABLE IF EXISTS `utilities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `utilities` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `icon` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `utilities`
--

LOCK TABLES `utilities` WRITE;
/*!40000 ALTER TABLE `utilities` DISABLE KEYS */;
INSERT INTO `utilities` VALUES (1,'fa fa-wifi',NULL,'Wi-Fi miễn phí'),(2,'fa fa-bath',NULL,'Bồn tắm'),(3,'fas fa-tv',NULL,'Tivi'),(4,'fa fa-calendar',NULL,'Miễn phí hủy phòng'),(5,'fa fa-door-open',NULL,'Cửa sổ'),(6,'fa fa-smoking',NULL,'Có thể hút thuốc'),(7,'fas fa-hamburger',NULL,'Miễn phí bữa sáng'),(8,'fa fa-couch',NULL,'Sofa'),(9,'fa fa-chair',NULL,'Ghế massage'),(10,'fa fa-user',NULL,'Nhân viên 24/7');
/*!40000 ALTER TABLE `utilities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `voucher`
--

DROP TABLE IF EXISTS `voucher`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `voucher` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `block` bit(1) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `discount` double DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `min_amount` double DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `voucher`
--

LOCK TABLES `voucher` WRITE;
/*!40000 ALTER TABLE `voucher` DISABLE KEYS */;
INSERT INTO `voucher` VALUES (2,_binary '','KD2',200000,'2025-05-31',1000000,'welcome ','2025-05-27'),(3,_binary '\0','summer',350000,'2025-06-25',1000000,'Summer','2025-06-05'),(4,_binary '\0','KK',1000000,'2025-06-19',500000,'welcome ','2025-06-12');
/*!40000 ALTER TABLE `voucher` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-26 14:29:33
