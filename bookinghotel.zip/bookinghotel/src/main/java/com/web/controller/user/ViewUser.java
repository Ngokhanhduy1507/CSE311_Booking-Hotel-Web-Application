package com.web.controller.user;

import com.web.entity.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class ViewUser {

    @RequestMapping(value = {"/","/index"}, method = RequestMethod.GET)
    public String home(Model model) {
        return "user/index";
    }

    @RequestMapping(value = {"/account"}, method = RequestMethod.GET)
    public String account() {
        return "user/account";
    }

    @RequestMapping(value = {"/confirm"}, method = RequestMethod.GET)
    public String confirm() {
        return "user/confirm";
    }

    @RequestMapping(value = {"/forgot"}, method = RequestMethod.GET)
    public String forgot() {
        return "user/forgot";
    }

    @RequestMapping(value = {"/khach-san"}, method = RequestMethod.GET)
    public String khachSan() {
        return "user/khach-san";
    }

    @RequestMapping(value = {"/login"}, method = RequestMethod.GET)
    public String login() {
        return "user/login";
    }

    @RequestMapping(value = {"/regis"}, method = RequestMethod.GET)
    public String regis() {
        return "user/regis";
    }

    @RequestMapping(value = {"/tim-khach-san"}, method = RequestMethod.GET)
    public String timKhachSan() {
        return "user/tim-khach-san";
    }

    @RequestMapping(value = {"/payment"}, method = RequestMethod.GET)
    public String payment() {
        return "user/payment";
    }


}
