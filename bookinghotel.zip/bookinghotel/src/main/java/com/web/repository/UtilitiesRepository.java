package com.web.repository;

import com.web.entity.Category;
import com.web.entity.Utilities;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UtilitiesRepository extends JpaRepository<Utilities,Long> {
}
