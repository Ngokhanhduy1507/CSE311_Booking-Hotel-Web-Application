package com.web.repository;

import com.web.entity.Comment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface CommentRepository extends JpaRepository<Comment, Long> {

    @Query("select c from Comment c where c.hotel.id = ?1")
    List<Comment> findByHotel(Long hotelId);

    @Query("select count(c.id) from Comment c where c.hotel.id = ?1")
    Long countCommentByHotel(Long hotelId);

    @Query("select sum(c.star) from Comment c where c.hotel.id = ?1")
    Float sumStarCommentByHotel(Long hotelId);
}
