package com.web.service;


import com.web.dto.DateResponse;
import com.web.dto.RoomDto;
import com.web.entity.*;
import com.web.enums.PayStatus;
import com.web.repository.BookingRoomRepository;
import com.web.repository.RoomImageRepository;
import com.web.repository.RoomRepository;
import com.web.repository.RoomUtilitiesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

@Service
public class RoomService {

    @Autowired
    private RoomRepository roomRepository;

    @Autowired
    private RoomImageRepository roomImageRepository;

    @Autowired
    private RoomUtilitiesRepository roomUtilitiesRepository;

    @Autowired
    private BookingRoomRepository bookingRoomRepository;

    public Room save(RoomDto roomDto){
        Room result = roomRepository.save(roomDto.getRoom());
        for(String s : roomDto.getListImage()){
            RoomImage roomImage = new RoomImage();
            roomImage.setImage(s);
            roomImage.setRoom(result);
            roomImageRepository.save(roomImage);
        }
        roomUtilitiesRepository.deleteByRoom(result.getId());
        for(Long id : roomDto.getListUtilityId()){
            RoomUtilities roomUtilities = new RoomUtilities();
            roomUtilities.setRoom(result);
            Utilities utilities = new Utilities();
            utilities.setId(id);
            roomUtilities.setUtilities(utilities);
            roomUtilitiesRepository.save(roomUtilities);
        }
        return result;
    }

    public List<Room> findAll (){
        List<Room> result = roomRepository.findAll();
        return result;
    }

    public List<Room> findByHotel (Long hotelId){
        List<Room> result = roomRepository.findByHotel(hotelId);
        return result;
    }

    public Room findById(Long id){
        return roomRepository.findById(id).get();
    }

    public void delete(Long id){
        roomRepository.deleteById(id);
    }

    public DateResponse calDate(Date from, Integer numDate, Long hotelId){
        DateResponse dateResponse = new DateResponse();
        Long longTo = from.getTime() + (1000L * 60L * 60L * 24L * (numDate));
        Date to = new Date(longTo);
        Calendar c = Calendar.getInstance();
        c.setTime(to);
        int dayOfWeek = c.get(Calendar.DAY_OF_WEEK); // 3
        DateFormat format2 = new SimpleDateFormat("EEEE");
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd 'thg' MM, YYYY");
        String day = simpleDateFormat.format(to);
        dateResponse.setToDate(to);
        dateResponse.setFromDate(from);
        dateResponse.setNumDate(numDate);
        dateResponse.setDetailDate("Thứ "+dayOfWeek+", "+day);
        List<BookingRoom> bookingRooms = bookingRoomRepository.bookingRoomByDate(from, to);

        List<Room> rooms = findByHotel(hotelId);

        for(int i=0; i< rooms.size(); i++){
            Boolean check = false;
            for(BookingRoom bk : bookingRooms){
                if(rooms.get(i).getId() == bk.getRoom().getId() &&
                        bk.getBooking().getPayStatus().equals(PayStatus.NOT_PAID)){
                    check = true;
                }
            }
            if(check){
                rooms.remove(rooms.get(i));
                --i;
            }
        }
        dateResponse.setRooms(rooms);
        dateResponse.setBookingRooms(bookingRooms);
        return dateResponse;
    }
}
