package com.web.api;

import com.web.dto.DateResponse;
import com.web.dto.RoomDto;
import com.web.entity.Room;
import com.web.service.RoomService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.sql.Date;
import java.util.List;

@RestController
@RequestMapping("/api/room")
@CrossOrigin
public class RoomApi {

    @Autowired
    private RoomService roomService;

    @PostMapping("/admin/create")
    public ResponseEntity<?> save(@RequestBody RoomDto roomDto){
        Room result = roomService.save(roomDto);
        return new ResponseEntity<>(result, HttpStatus.CREATED);
    }

    @DeleteMapping("/admin/delete")
    public ResponseEntity<?> delete(@RequestParam("id") Long id){
        roomService.delete(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @GetMapping("/public/findAll")
    public ResponseEntity<?> findAll(){
        List<Room> result = roomService.findAll();
        return new ResponseEntity<>(result,HttpStatus.OK);
    }

    @GetMapping("/public/find-by-hotel")
    public ResponseEntity<?> findByHotel(@RequestParam Long hotelId){
        List<Room> result = roomService.findByHotel(hotelId);
        return new ResponseEntity<>(result,HttpStatus.OK);
    }

    @GetMapping("/admin/findById")
    public ResponseEntity<?> findById(@RequestParam("id") Long id){
        Room result = roomService.findById(id);
        return new ResponseEntity<>(result,HttpStatus.OK);
    }

    @GetMapping("/public/findById")
    public ResponseEntity<?> findByIdUser(@RequestParam("id") Long id){
        Room result = roomService.findById(id);
        return new ResponseEntity<>(result,HttpStatus.OK);
    }

    @GetMapping("/public/cal-date")
    public ResponseEntity<?> save(@RequestParam("from") Date from, @RequestParam("numDate") Integer numDate,
                                  @RequestParam Long hotelId){
        DateResponse result = roomService.calDate(from, numDate,hotelId);
        return new ResponseEntity<>(result, HttpStatus.OK);
    }
}
