package com.web.api;

import com.web.entity.Comment;
import com.web.service.CommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/comment")
public class CommentApi {

    @Autowired
    private CommentService commentService;

    @PostMapping("/public/create")
    public ResponseEntity<?> save(@RequestBody Comment comment){
        Comment result = commentService.save(comment);
        return new ResponseEntity<>(result, HttpStatus.CREATED);
    }

    @GetMapping("/public/find-by-hotel")
    public ResponseEntity<?> findAll(@RequestParam Long hotelId){
        List<Comment> list = commentService.findByHotel(hotelId);
        return new ResponseEntity<>(list, HttpStatus.OK);
    }
}
