package com.web.dto;

public interface DanhMucDto {

    public Long getId();

    public String getTen();

    public Long getQuantity();
}
