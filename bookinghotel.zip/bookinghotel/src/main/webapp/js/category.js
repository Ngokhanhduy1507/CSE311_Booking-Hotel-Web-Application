async function loadCategoryIndex() {
    var url = 'http://localhost:8080/api/category/public/findAll-list';
    const response = await fetch(url, {});
    var list = await response.json();
    console.log(list)
    var main = `<div class="listdmindex owl-2-style"><div class="owl-carousel owl-2" id="listcategoryindex">`
    main += `<div class="media-29101">
                <div onclick="loadKhachSanIndex(0,'Tất cả khách sạn'', null)" class="singledanhmuc"><span>Tất cả</span></div>
            </div>`;
    for (i = 0; i < list.length; i++) {
        main += `<div class="media-29101">
                    <div onclick="loadKhachSanIndex(0,'Khách sạn: ${list[i].name}', ${list[i].id})" class="singledanhmuc"><span>${list[i].name}</span></div>
                </div>`;
    }
    main += `</div></div>`
    document.getElementById("dsmh_index").innerHTML = main;
    loadCou();
}


async function loadCategoryKs() {
    var url = 'http://localhost:8080/api/category/public/findAll-list';
    const response = await fetch(url, {});
    var list = await response.json();
    console.log(list)
    var main = `<option value="-1">Tất cả khách sạn</option>`;
    for (i = 0; i < list.length; i++) {
        main += `<option value="${list[i].id}">${list[i].name}</option>`;
    }
    document.getElementById("listcategoryselect").innerHTML = main;
}


async function loadCategorySearch() {
    var uls = new URL(document.URL)
    var id = uls.searchParams.get("loaiphong");
    var url = 'http://localhost:8080/api/category/public/findAll-list';
    const response = await fetch(url, {});
    var list = await response.json();
    var main = ``;
    for (i = 0; i < list.length; i++) {
        main += `<div class="col-sm-6">
                    <label class="checkbox-custom">${list[i].name}
                        <input ${(id == list[i].id || id == -1)?'checked':''} type="checkbox" name="danhmucsearch" value="${list[i].id}">
                        <span class="checkmark-checkbox"></span>
                    </label>
                </div>`;
    }
    document.getElementById("listdm").innerHTML = main;
}