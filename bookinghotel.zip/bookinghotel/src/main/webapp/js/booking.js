async function createUrl() {
    var arr = [];
    var total = 0;
    for(i=0; i<listRoomArr.length; i++){
        arr.push(listRoomArr[i].id)
        total += Number(listRoomArr[i].price) * document.getElementById("songay").value
    }

    swal({
        title: "Xác nhận thanh toán?",
        text: "Xác nhận thanh toán "+formatmoney(total)+" qua VNPAY",
        type: "warning",
        showCancelButton: true,
        confirmButtonText: "OK",
        cancelButtonText: "Hủy",
        closeOnConfirm: false,
        closeOnCancel: true
    },
    function(isConfirm) {
        if (isConfirm) {
            confirmTT();
        } else {
            return;
        }
    });

}

async function confirmTT(){
    var arr = [];
    var total = 0;
    for(i=0; i<listRoomArr.length; i++){
        arr.push(listRoomArr[i].id)
        total += Number(listRoomArr[i].price) * document.getElementById("songay").value
    }
    var bookingDto = {
        "fromDate": document.getElementById("fromdate").value,
        "numDate": document.getElementById("songay").value,
        "fullname": document.getElementById("hotendp").value,
        "phone": document.getElementById("phonedp").value,
        "cccd": document.getElementById("cccddp").value,
        "note": document.getElementById("ghichudp").value,
        "voucherCode":document.getElementById("makhuyenmai").value == "" ? null : document.getElementById("makhuyenmai").value,
        "listRoomId": arr,
    }

    var paymentDto = {
        "codeVoucher":document.getElementById("makhuyenmai").value == "" ? null : document.getElementById("makhuyenmai").value,
        "content":"Thanh toán đơn đặt phòng",
        "returnUrl":"http://localhost:8080/payment",
        "notifyUrl":"http://localhost:8080/payment",
        "numDate":document.getElementById("songay").value,
        "listRoomId":arr
    }
    var url = 'http://localhost:8080/api/vnpay/urlpayment';
    const res = await fetch(url, {
        method: 'POST',
        headers: new Headers({
            'Content-Type': 'application/json'
        }),
        body: JSON.stringify(paymentDto)
    });
    var result = await res.json();
    if (res.status < 300) {
        localStorage.setItem("bookingDto", JSON.stringify(bookingDto))
        window.location.href = result.url
    }
    if (res.status == exceptionCode) {
        if(document.getElementById("makhuyenmai").value != ""){
            toastr.warning(result.defaultMessage);
            document.getElementById("makhuyenmai").value = "";
        }
    }
}


async function createBooking() {
    var bookingDto = localStorage.getItem("bookingDto");
    if(bookingDto != null){
        bookingDto = JSON.parse(bookingDto);
    }
    var uls = new URL(document.URL)
    var vnpOrderInfo = uls.searchParams.get("vnp_OrderInfo");
    const currentUrl = window.location.href;
    const parsedUrl = new URL(currentUrl);
    const queryStringWithoutQuestionMark = parsedUrl.search.substring(1);
    var urlVnpay = queryStringWithoutQuestionMark
    bookingDto.vnpOrderInfo = vnpOrderInfo;
    bookingDto.urlVnpay = urlVnpay;

    var url = 'http://localhost:8080/api/booking/public/create-booking';
    const res = await fetch(url, {
        method: 'POST',
        headers: new Headers({
            'Content-Type': 'application/json'
        }),
        body: JSON.stringify(bookingDto)
    });
    if (res.status < 300) {
        swal({
            title: "Thông báo",
            text: "Đặt phòng thành công!",
            type: "success"
        }, function() {
            window.location.href = 'account'
        });
    }
    if (res.status == exceptionCode) {
        var result = await res.json();
        document.getElementById("thatbai").style.display = 'block'
        document.getElementById("thanhcong").style.display = 'none'
        document.getElementById("errormess").innerHTML = result.defaultMessage
    }

}


async function myBooking() {
    var url = 'http://localhost:8080/api/booking/user/my-booking';
    const response = await fetch(url, {
        method: 'POST'
    });
    var list = await response.json();
    var main = '';
    var total = 0;
    for(i=0; i<list.length; i++){
        total = Number(total)+Number(1)
        main +=
            `<tr>
            <td><a class="yls">#${list[i].id}</a></td>
            <td class="floatr">${list[i].createdTime} ${list[i].createdDate}</td>
            <td>${list[i].fromDate}</td>
            <td class="floatr">${list[i].numDate}</td>
            <td>${list[i].fullname}</td>
            <td class="floatr">${list[i].phone}</td>
            <td><span class="span_pending">${loadTrangThai(list[i].payStatus)}</span></td>
            <td class="floatr"><span class="span_"><span class="yls">${formatmoney(list[i].amountRoom)}</span></span></td>
            <td class="floatr"><span class="span_"><span class="yls">${formatmoney(list[i].discount)}</span></span></td>
            <td><button onclick="bookingRoomDetail(${list[i].id})" data-bs-toggle="modal" data-bs-target="#modaldeail" class="btn btn-primary">Chi tiết</button></td>
        </tr>`
    }
    document.getElementById("listBooking").innerHTML = main;
    document.getElementById("sldonhang").innerHTML = total+" đơn đặt phòng";
}



async function bookingRoomDetail(id) {
    var url = 'http://localhost:8080/api/booking-room/public/find-by-booking?id='+id;
    const response = await fetch(url, {
        method: 'POST'
    });
    var list = await response.json();
    var main = '';
    for(i=0; i<list.length; i++){
        main +=
            `<tr>
            <td><img src="${list[i].room.image}" class="imgdetailacc" style="width:100%"></td>
            <td>${list[i].room.name}</td>
            <td>${formatmoney(list[i].price)} / Ngày</td>
        </tr>`
    }
    document.getElementById("listBookingRoom").innerHTML = main;
}



function loadTrangThai(name){
    if(name == "NOT_PAID"){
        return "<span class='dadatcoc'>Chưa thanh toán</span>";
    }
    if(name == "PAID"){
        return "<span class='dathanhtoan'>Đã thanh toán</span>";
    }
    if(name == "CANCELLED"){
        return "<span class='dahuy'>Đã hủy</span>";
    }
}