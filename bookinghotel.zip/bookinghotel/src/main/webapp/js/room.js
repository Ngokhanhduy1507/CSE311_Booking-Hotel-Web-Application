
async function loadAllRoom() {
    var uls = new URL(document.URL)
    var hotelId = uls.searchParams.get("id");
    var from = document.getElementById("fromdate").value
    var songay = document.getElementById("songay").value
    var url = 'http://localhost:8080/api/room/public/cal-date?from='+from+'&numDate='+songay+"&hotelId="+hotelId;
    const response = await fetch(url, {
        method: 'GET'
    });
    var result = await response.json();
    var list = result.rooms
    
    var main = '';
    for (i = 0; i < list.length; i++) {
        var tienich = '';
        for(j=0; j<list[i].roomUtilities.length; j++){
            tienich += `<div class="col-sm-6 singletich">
            <i class="${list[i].roomUtilities[j].utilities.icon}"></i> ${list[i].roomUtilities[j].utilities.name}
        </div>`
        }
        main += `<div class="row singleroom">
        <div class="col-4">
            <img onclick="loadDetailRoom(${list[i].id})" src="${list[i].image}" data-bs-toggle="modal" data-bs-target="#modaldeail" class="imgroom pointer">
        </div>
        <div class="col-8">
            <div class="nameroomdiv">
                <span class="roomnames pointer">${list[i].name}</span>
                <span data-bs-toggle="modal" data-bs-target="#modaldeail" class="motaroom pointer">Xem mô tả & ảnh phòng</span>
            </div>
            <div class="d-flex numbedroom">
                <span><i class="fa fa-bed"></i> Số giường: ${list[i].numBed}</span>
                <span><i class="fa fa-users"></i> Số người tối đa: ${list[i].maxPeople}</span>
            </div>
            <div class="row">
                <div class="col-8">
                    <div class="row">${tienich}</div>
                </div>
                <div class="col-4">
                    <span class="priceroom">${formatmoney(list[i].price)}</span>
                    <span class="phongdem">/ phòng / đêm</span>
                    <label class="checkbox-custom"> Chọn phòng
                        <input id="inputcheck${list[i].id}" onchange="pushToList(this,${list[i].id},'${list[i].name}',${list[i].price})" type="checkbox"><span class="checkmark-checkbox"></span>
                    </label>
                </div>
            </div>
        </div>
    </div>`
    }
    document.getElementById("listRoom").innerHTML = main
    document.getElementById("sophongtrong").innerHTML = "("+list.length +' phòng)'
    loadRoomSelect();
}

var listRoomArr = [];
async function pushToList(e, id, roomname, price){
    if(e.checked == false){
        removeRoom(id);
    }
    else{
        var obj = {
            "id":id,
            "roomname":roomname,
            "price":price,
        }
        listRoomArr.push(obj);
    }
    loadRoomSelect();
}


function loadRoomSelect(){
    var main = '';
    for(i=0; i<listRoomArr.length;i++){
        main += `<div class="row">
        <div class="col-7"><span>${listRoomArr[i].roomname}</span></div>
        <div class="col-3"><span>${formatmoney(listRoomArr[i].price)} / ngày</span></div>
        <div onclick="removeRoom(${listRoomArr[i].id})" class="col-2"><i class="fa fa-trash pointer"></i></div>
    </div>`;
    try {
        document.getElementById("inputcheck"+listRoomArr[i].id).checked = true;
    } catch (error) {}
    }
    document.getElementById("listroomdc").innerHTML = main;
    if(listRoomArr.length > 0){
        document.getElementById("divxacnhanthanhtoan").style.display = 'block'
    }
    else{
        document.getElementById("divxacnhanthanhtoan").style.display = 'none'
    }
}

function removeRoom(id){
	listRoomArr = listRoomArr.filter(data => data.id != id);
    loadRoomSelect();
    document.getElementById("inputcheck"+id).checked = false;
}
